import React, { useState, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import CustomButton from "../../components/Button/Button";
import { CustomeCalender } from "../../components/Calender/CustomeCalender";

import { InputText } from "primereact/inputtext";
import { Calendar } from "primereact/calendar";
import { Toast } from "primereact/toast";
import { FileUpload } from "primereact/fileupload";
import * as XLSX from "xlsx";
import {
  showSuccessMessage,
  showErrorMessage,
  showWarningMessage,
} from "../../components/Toast/ShowMessage";

import {
  formateDate,
  savetodraft,
  updateDraftdata,
  downloadTourClaimExpanseDocument,
} from "./claimServices";

const cellStyle = { padding: "8px 12px" };

const initialFormState = {
  // id: Date.now(),
  Date: "",
  Lodging: "",
  Breakfast: "",
  Lunch: "",
  Snacks: "",
  Dinner: "",
  "Tea & Water": "",
  "Airfare, Bus, Train, Taxi Rental": "",
  "Auto, Cab": "",
  "Parking, Toll, Fuel": "",
  Incidentals: "",
  "Other Business Expenses": "",
  Total: "",
  Remarks: "",
};

const TourClaimTable = ({
  editableMode,
  seteditableMode,
  toggleNewClaim,
  settoggleNewClaim,
  settourClaimTableData,
  tourClaimTableData,
  settourclaimFormLabeData,
  tourclaimformData,
  settourclaimformData,
  setDraftData,
  draftData,
  setFormErrors,
  formErrors,
  setselectedtravelMode,
}) => {
  // const [editingIndex, setEditingIndex] = useState(null);
  const [editingRows, setEditingRows] = useState({});
  const toastRef = useRef(null);
  const [fileUploaded, setFileUploaded] = useState(false);

  // const calculateTotal = (entry) => {
  //   const keys = Object.keys(initialFormState).filter(
  //     (k) => k !== "Date" && k !== "Remarks"
  //   );
  //   return keys.reduce((sum, key) => sum + (parseFloat(entry[key]) || 0), 0);
  // };

  const calculateTotal = (entry) => {
    const keys = Object.keys(initialFormState).filter(
      (k) => k !== "Date" && k !== "Remarks" && k !== "Total",
    );

    let sum = 0;

    sum = keys.reduce((acc, key) => {
      return acc + (parseFloat(entry[key]) || 0);
    }, 0);

    return sum;
  };

  const hasDuplicateDatesOrZeroTotal = (data) => {
    const seen = new Set();
    for (let row of data) {
      const date = row["Date"];
      // const total = parseFloat(row["Total"]) || 0;
      if (!date) return { hasIssue: true, reason: "Date cann't be null" };
      if (seen.has(date))
        return { hasIssue: true, reason: "Duplicate date found" };
      seen.add(date);
      // if (total === 0)
      //   return { hasIssue: true, reason: "Total amount cann't be zero" };
    }
    return { hasIssue: false };
  };
  const validateForm = () => {
    const requiredFields = [
      "travelType",
      "destination",
      "purpose",
      "projectName",
      "onAccount",
      // "travelfromDate",
      "claimFromDate",
      "claimToDate",
      //"advanceRequested",
    ];

    const errors = {};

    requiredFields.forEach((field) => {
      if (
        !tourclaimformData[field] ||
        tourclaimformData[field].toString().trim() === ""
      ) {
        errors[field] = true;
      }
    });

    setFormErrors(errors); // highlight those with errors

    return Object.keys(errors).length === 0; // valid if no errors
  };

  const handleChange = (e, rowIndex) => {
    const { name, value } = e.target;
    const updatedData = [...tourClaimTableData];
    updatedData[rowIndex] = {
      ...updatedData[rowIndex],
      [name]: value,
    };
    // updatedData[rowIndex]["Total"] = calculateTotal(updatedData[rowIndex]);
    settourClaimTableData(updatedData);
  };

  const handleDateChange = (e, rowIndex) => {
    const updatedData = [...tourClaimTableData];
    updatedData[rowIndex]["Date"] = formateDate(e.value); //e.value?.toISOString().split("T")[0] || "";
    settourClaimTableData(updatedData);
  };

  const openEditMode = (index) => {
    const updatedData = [...tourClaimTableData];
    updatedData[index]["Total"] = 0; // Reset only the Total
    settourClaimTableData(updatedData);
    setEditingIndex(index);
  };

  const deleteRow = (rowData) => {
    settourClaimTableData(
      tourClaimTableData.filter((item) => item.Date !== rowData.Date),
    );
  };
  // const deleteRow = (index) => {

  //   const updated = tourClaimTableData.filter((_, i) => i !== index);
  //   settourClaimTableData(updated);
  //   setEditingIndex(null);
  // };

  const handleAddRow = () => {
    // Check if upper form has errors
    // const requiredFields = ["purpose", "projectName", "city", "localityArea", "typeOfTravel", "fromDate", "tentativeToDate"];
    // const upperFormIncomplete = requiredFields.some((field) => formErrors[field]);

    // if (upperFormIncomplete) {
    //   showWarningMessage(toastRef,"Please complete requisition form before adding accommodation.");
    //   return;
    // }

    if (
      !tourclaimformData.destination ||
      !tourclaimformData.purpose ||
      !tourclaimformData.projectName ||
      !tourclaimformData.projectName ||
      !tourclaimformData.claimFromDate ||
      !tourclaimformData.claimToDate
    ) {
      showWarningMessage(
        toastRef,
        "Please complete claim details form before adding expense.",
      );
      return;
    }
    const isIncomplete = tourClaimTableData.some((row) => !row.Date);

    if (isIncomplete) {
      showWarningMessage(toastRef, "Please complete all required fields.");
      return;
    }

    settourClaimTableData([
      ...tourClaimTableData,
      { ...initialFormState, Total: 0 },
    ]);

    setEditingRows((prev) => ({ ...prev, [initialFormState.Date]: true }));
    // setEditingIndex(tourClaimTableData.length);
  };

  const onFileSelect = (event) => {
    const file = event.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
      const bstr = e.target.result;
      const workbook = XLSX.read(bstr, { type: "binary" });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];

      const headerRowIndex = 15;
      //const headerRowIndex = 0;
      const headers = XLSX.utils.sheet_to_json(worksheet, {
        range: headerRowIndex,
        header: 1,
      })[0];

      // settourclaimFormLabeData({
      //   destination: worksheet["C12"]?.v || "",
      //   purposeOfTrip: worksheet["C13"]?.v || "",
      //   projectName: worksheet["J9"]?.v || "",
      //   onAccount: worksheet["J10"]?.v || "",
      //   fromDate: formateDate(worksheet["J11"]?.v),
      //   toDate: formateDate(worksheet["J12"]?.v),
      // });

      const jsonData = XLSX.utils.sheet_to_json(worksheet, {
        range: 15,
        // range: 0,
        header: headers,
        defval: "",
      });
      console.log(" Raw Excel JSON:", jsonData);

      // Index the rows already in the table by date (YYYY-MM-DD)
      const updatedRows = [...tourClaimTableData];
      const rowIndexByDate = new Map();
      updatedRows.forEach((r, i) => {
        const key = formateDate(r["Date"]);
        if (key) rowIndexByDate.set(key, i);
      });

      let filledCount = 0;
      let skippedRows = 0;
      const extraDates = [];

      jsonData.forEach((row) => {
        // Rows without a readable date (blank / footer / totals rows) are skipped
        const parsedDate = formateDate(row["Date"]);
        if (!parsedDate) {
          skippedRows++;
          return;
        }

        const importedRow = { ...initialFormState, Date: parsedDate };

        for (const key of Object.keys(initialFormState)) {
          if (key === "Date") continue;

          let excelKey = key;
          // Fix mismatch header coming from Excel
          if (key === "Airfare, Bus, Train, Taxi Rental") {
            excelKey = "Airfare, Bus, Train,Taxi Rental";
          }

          if (key === "Remarks") {
            importedRow[key] = row[excelKey] ?? "";
          } else {
            const num = parseFloat(row[excelKey]);
            importedRow[key] = !isNaN(num) ? num : 0;
          }
        }
        importedRow["Total"] = calculateTotal(importedRow);

        if (rowIndexByDate.has(parsedDate)) {
          // Date already present in the table -> fill that row
          const idx = rowIndexByDate.get(parsedDate);
          updatedRows[idx] = { ...updatedRows[idx], ...importedRow };
          filledCount++;
        } else {
          // Date outside the claim period -> not added, reported below
          extraDates.push(parsedDate);
        }
      });

      // Excel has dates outside the claim period -> block the whole import
      if (extraDates.length > 0) {
        const sorted = [...extraDates].sort();
        showWarningMessage(
          toastRef,
          `Import blocked: Excel has ${extraDates.length} date(s) outside the claim period ` +
            `(${sorted[0]} to ${sorted[sorted.length - 1]}). ` +
            `Please match Claim From Date and Claim To Date with the date range in the Excel and upload again.`,
        );
        setFileUploaded(false);
        return;
      }

      if (filledCount === 0) {
        showWarningMessage(
          toastRef,
          "No rows with a valid date were found in the Excel file.",
        );
        setFileUploaded(false);
        return;
      }

      settourClaimTableData(updatedRows);
      setFileUploaded(true);

      showSuccessMessage(
        toastRef,
        "success",
        `${filledCount} row(s) filled` +
          (skippedRows ? `, ${skippedRows} row(s) skipped (no valid date).` : "."),
      );
    };

    reader.readAsBinaryString(file);
  };

  const handleSaveToDraft = async () => {
    try {
      console.log("formErrors", formErrors);
      console.log("draftdata", draftData);
      if (!validateForm()) {
        //const firstKey = Object.keys(formErrors)[0];
        if (toastRef?.current) {
          showErrorMessage(
            toastRef,
            "Error",
            `Please fill in all required fields.`,
          );
        }

        return;
      }
      const response = await savetodraft(tourclaimformData, tourClaimTableData);
      //   if (response?.success) {
      if (!response.status) {
        showErrorMessage(toastRef, "error", response.message);
      } else {
        showSuccessMessage(toastRef, "success", response.message);

        setDraftData(response.data);
        seteditableMode(false);
        settoggleNewClaim(false);
        settourClaimTableData([]);
        setselectedtravelMode(null);
      }
    } catch (error) {
      showErrorMessage(toastRef, "error", error?.message);

      console.log(error);
    }
  };

  const handleUpdate = async () => {
    try {
      if (!validateForm()) {
        //const firstKey = Object.keys(formErrors)[0];
        if (toastRef?.current) {
          showErrorMessage(
            toastRef,
            "Error",
            `Please fill in all required fields.`,
          );
        }

        return;
      }
      const response = await updateDraftdata(
        tourclaimformData,
        tourClaimTableData,
        tourclaimformData.claim_id,
      );
      console.log("response", response);
      if (!response.status) {
        showErrorMessage(toastRef, "error", response.message);
      } else {
        showSuccessMessage(toastRef, "success", response.message);
        setDraftData(response.data);
        seteditableMode(false);
        settourClaimTableData([]);
        setselectedtravelMode(null);
      }
    } catch (error) {
      showErrorMessage(toastRef, "error", error?.message);

      console.log(error);
    }
  };
  // const renderCell = (rowData, field, rowIndex) => {
  //   if (editingIndex === rowIndex) {
  //     if (field === "Date") {
  //       return (
  //         <Calendar
  //           value={rowData["Date"] ? new Date(rowData["Date"]) : null}
  //           onChange={(e) => handleDateChange(e, rowIndex)}
  //           dateFormat="dd-mm-yy"
  //           showIcon
  //           className="p-inputtext-sm w-full"
  //           minDate={
  //             tourclaimformData.claimFromDate
  //               ? new Date(tourclaimformData.claimFromDate)
  //               : null
  //           }
  //           maxDate={
  //             tourclaimformData.claimToDate
  //               ? new Date(tourclaimformData.claimToDate)
  //               : null
  //           }
  //         />
  //       );
  //     } else if (field == "Remarks") {
  //       return (
  //         <InputText
  //           name={field}
  //           value={rowData[field] || ""}
  //           onChange={(e) => handleChange(e, rowIndex)}
  //           className="p-inputtext-sm w-full"
  //         />
  //       );
  //     } else if (field == "Total") {
  //       return (
  //         <InputText
  //           name={field}
  //           value={rowData[field] || ""}
  //           onChange={(e) => handleChange(e, rowIndex)}
  //           className="p-inputtext-sm w-full"
  //           disabled
  //         />
  //       );
  //     }

  //     return (
  //       <InputText
  //         name={field}
  //         value={rowData[field] || ""}
  //         onChange={(e) => handleChange(e, rowIndex)}
  //         onKeyPress={(e) => {
  //           const key = e.key;
  //           const currentValue = rowData[field] || "";

  //           // Allow digits and a single dot
  //           if (!/[\d.]/.test(key)) {
  //             e.preventDefault();
  //           }

  //           // Prevent more than one dot
  //           if (key === "." && currentValue.includes(".")) {
  //             e.preventDefault();
  //           }
  //         }}
  //         onPaste={(e) => {
  //           const paste = e.clipboardData.getData("text");
  //           // Allow only valid float numbers
  //           if (!/^\d*\.?\d*$/.test(paste)) {
  //             e.preventDefault();
  //           }
  //         }}
  //         className="p-inputtext-sm w-full"
  //       />
  //     );
  //   }
  //   return <span>{rowData[field]}</span>;
  // };

  const actionBodyTemplate = (row, { rowIndex }) => (
    <div className="flex gap-2">
      {/* {editingIndex === rowIndex ? (
        <CustomButton
          icon="pi pi-check"
          className="p-button-sm p-button-success"
          onClick={() => {
            // const result = hasDuplicateDatesOrZeroTotal(tourClaimTableData);
            // if (result.hasIssue) {
            //   toast.current?.show({
            //     severity: "warn",
            //     summary: "Validation Warning",
            //     detail: result.reason,
            //   });
            //   return;
            // }

            const updated = [...tourClaimTableData];
            updated[editingIndex]["Total"] = calculateTotal(
              updated[editingIndex]
            );
            settourClaimTableData(updated);
            setEditingIndex(null);
          }}
        />
      ) : (
        <CustomButton
          icon="pi pi-pencil"
          className="p-button-sm p-button-text p-button-info"
          onClick={() => openEditMode(rowIndex)}
        />
      )} */}
      <CustomButton
        icon="pi pi-trash"
        className="p-button-sm p-button-text p-button-danger"
        // onClick={() => handleDelete(rowIndex)}
        onClick={() => deleteRow(row)}
      />
    </div>
  );

  const fields = Object.keys(initialFormState);
  // const handleDownloadFile = async () => {
  //   try {
  //     let d = await downloadTourClaimExpanseDocument();
  //   } catch (error) {
  //     console.log(error);
  //   }
  // };
  const allowEdit = (rowData) => {
    return rowData.name !== "Blue Band";
  };

  const onRowEditComplete = (e) => {
    let _tourClaimTableData = [...tourClaimTableData];
    let { newData, index } = e;

     const formattedDate = formateDate(newData.Date);

  if (!formattedDate) {
    showWarningMessage(toastRef, "warn", "Date cannot be empty");
    return;
  }

     //  Duplicate date check (ignore current row)
  const duplicate = _tourClaimTableData.some(
    (row, i) => i !== index && row.Date === formattedDate
  );

  if (duplicate) {
    showWarningMessage(toastRef, "warn", "Duplicate date not allowed");
    return;
  }

    newData.Total = calculateTotal(newData);
    newData.Date = formateDate(newData.Date);
    //calculateTotal(newData)
    if (!newData.Date) {
      showWarningMessage(toastRef, "warn", "Date Cannot be Empty");
      return;
    }

    _tourClaimTableData[index] = newData;

    settourClaimTableData(_tourClaimTableData);
  };

  const textEditor = (options) => {
    console.log("texteditoroptions", options);
    const handleChange = (e) => {
      const value = e.target.value;

      // Allow only non-negative numbers with optional decimals
      if (value === "" || /^\d*\.?\d*$/.test(value)) {
        options.editorCallback(value);
      }
    };
    return (
      <InputText
        type="text"
        value={options.value}
        onChange={handleChange}
        // onChange={(e) => options.editorCallback(e.target.value)}
        className="p-inputtext-sm w-full inputFieldStyle"
        //className="text-xs  w-full"
      />
    );
  };

  const textEditor2 = (options) => {
    console.log("texteditoroptions", options);
    return (
      <InputText
        type="text"
        value={options.value}
        onChange={(e) => options.editorCallback(e.target.value)}
        className="p-inputtext-sm w-full inputFieldStyle"
        //className="text-xs  w-full"
      />
    );
  };
  // "2025-11-04" -> local Date (new Date("2025-11-04") would be read as UTC
  // and could land on the previous day in some timezones)
  const toLocalDate = (value) => {
    if (typeof value === "string") {
      const m = value.match(/^(\d{4})-(\d{2})-(\d{2})/);
      if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
    }
    return new Date(value);
  };

  const dateEditor = (options) => {
    // A row that already has a date shows it in a disabled calendar, so it
    // looks like the editor but can't be changed. Only rows with a blank
    // date (added with the "+" button) get a working calendar. We check the
    // saved row in the table, not the row being edited, so a blank row
    // doesn't lock itself the moment a date is picked.
    const savedRow = tourClaimTableData[options.rowIndex];
    options.value=toLocalDate(savedRow.Date)
    return (
      <CustomeCalender
        value={options.value}
        onChange={(e) => options.editorCallback(e.value)}
        minDate={new Date(tourclaimformData.claimFromDate)}
        maxDate={new Date(tourclaimformData.claimToDate)}
      />
    );
  };

  const calculateColumnTotals = () => {
    const totals = {};

    Object.keys(initialFormState).forEach((key) => {
      if (key !== "Date" && key !== "Remarks") {
        totals[key] = tourClaimTableData.reduce((sum, row) => {
          return sum + (parseFloat(row[key]) || 0);
        }, 0);
      }
    });

    return totals;
  };

  const columnTotals = calculateColumnTotals();
  return (
    <>
      <Toast ref={toastRef} />
      <div className="flex justify-end mb-2 gap-3 align-items-center  mr-2">
        {/* {fileUploaded?( */}
        {/* <FileUpload
          mode="basic"
          name="file"
          accept=".xls,.xlsx"
          customUpload
          uploadHandler={onFileSelect}
          maxFileSize={1000000}
          chooseLabel="Upload"
        /> */}
        {/* ): <CustomButton
              icon="pi pi-times"
              className="p-button-sm p-button-text p-button-danger"
              onClick={() => {
                setFileUploaded(false);
              }}
              tooltip="ReUpload"
            />} */}
        {!fileUploaded ? (
          <FileUpload
            mode="basic"
            name="file"
            accept=".xls,.xlsx"
            customUpload
            auto
            uploadHandler={(e) => {
              onFileSelect(e);
              // Reset the uploader so the same file can be chosen again
              // (e.g. after the claim dates are corrected)
              e.options?.clear?.();
            }}
            maxFileSize={50000000}
            chooseLabel="Upload Excel"
            className="selectButtonStyle"
          />
        ) : (
          <div className="flex align-items-center gap-2 mt-2">
            <span className="text-green-600 font-medium">
              File uploaded successfully
            </span>
            <Button
              icon="pi pi-refresh"
              className="p-button-sm p-button-text p-button-warning"
              onClick={() => {
                setFileUploaded(false);
              }}
              tooltip="Re-upload"
              tooltipOptions={{ position: "top" }}
            />
          </div>
        )}

        {/* <CustomButton
          // label="Add Row"
          icon="pi pi-plus"
          className="p-button-sm "
          onClick={handleAddRow}
          tooltip="Add Row"
          rounded={"true"}
           size="small"
          style={{width:"1rem",height:"2.1rem"}}
          
        /> */}
        {/* <CustomButton
          icon="pi pi-file-export"
          className="p-button-sm"
          onClick={() => {
            handleDownloadFile();
          }}
          tooltip="Export Excel"
          rounded={"true"}
          severity={"success"}
          style={{width:"1rem",height:"2.1rem"}}
        /> */}
      </div>

      <div>
        <DataTable
          value={tourClaimTableData}
          showGridlines
          // scrollable
          // scrollHeight="250px"
          editingRows={editingRows}
          editMode="row"
          dataKey="Date"
          onRowEditChange={(e) => setEditingRows(e.data)}
          className=" dataTableHeader dataTableBody dataTableBodyPadding dataTablePaginator defaultBorder dataTableFooter"
          tableStyle={{ fontSize: "0.7rem" }}
          onRowEditComplete={onRowEditComplete}
          footerColumnGroup={null}
          header="Date-wise Details"
          size="small"
          stripedRows
        >
          {/* {fields.map((field) => (
          <Column
            key={field}
            header={field}
            body={(rowData, options) =>
              renderCell(rowData, field, options.rowIndex)
            }
            headerStyle={{
              ...cellStyle,
              width: field === "Date" ? "100px" : undefined, // wider width for Date
            }}
            bodyStyle={{
              ...cellStyle,
              width: field === "Date" ? "100px" : undefined,
            }}
          />
        ))} */}
          {/* <Column field="Date" header="Date" editor={(options) => textEditor(options)} style={{ width: '10%' }}/> */}
          <Column
            field="Date"
            header="Date"
            editor={dateEditor}
            body={(row) => (row.Date ? formateDate(row.Date) : "")}
            footer="Total"
            style={{ width: "115px" }}
          />
          {/* <Column
          field="Date"
          header="Date"
          editor={dateEditor}
          // editor={(options) => (
          //   <Calendar
          //     value={
          //       options.value ? new Date(options.value) : null
          //     }
          //     onChange={(e) => handleDateChange(e, options.rowIndex)}
          //    // onChange={(e) => options.editorCallback(e.target.value)}s
          //     dateFormat="dd-mm-yy"
          //     className="p-inputtext-sm w-full"
          //     style={{ minWidth: "105px" }}
          //       minDate={
          //     tourclaimformData.claimFromDate
          //       ? new Date(tourclaimformData.claimFromDate)
          //       : null
          //   }
          //   maxDate={
          //     tourclaimformData.claimToDate
          //       ? new Date(tourclaimformData.claimToDate)
          //       : null
          //   }
          //   />
          // )}
        /> */}
          <Column
            field="Lodging"
            header="Lodging"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Lodging"]?.toFixed(2)}
          />
          <Column
            field="Breakfast"
            header="Breakfast"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Breakfast"]?.toFixed(2)}
          />
          <Column
            field="Lunch"
            header="Lunch"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Lunch"]?.toFixed(2)}
          />
          <Column
            field="Snacks"
            header="Snacks"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Snacks"]?.toFixed(2)}
          />
          <Column
            field="Dinner"
            header="Dinner"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Dinner"]?.toFixed(2)}
          />
          <Column
            field="Tea & Water"
            header="Tea & Water"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Tea & Water"]?.toFixed(2)}
          />
          <Column
            field="Airfare, Bus, Train, Taxi Rental"
            header="Airfare, Bus, Train, Taxi Rental"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Airfare, Bus, Train, Taxi Rental"]?.toFixed(
              2,
            )}
          />
          <Column
            field="Auto, Cab"
            header="Auto, Cab"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Auto, Cab"]?.toFixed(2)}
          />
          <Column
            field="Parking, Toll, Fuel"
            header="Parking, Toll, Fuel"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Parking, Toll, Fuel"]?.toFixed(2)}
          />
          <Column
            field="Incidentals"
            header="Incidentals"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Incidentals"]?.toFixed(2)}
          />
          <Column
            field="Other Business Expenses"
            header="Other Business Expenses"
            editor={(options) => textEditor(options)}
            footer={columnTotals["Other Business Expenses"]?.toFixed(2)}
          />
          <Column
            field="Total"
            header="Total"
            // editor={(options) => textEditor(options)}
            footer={columnTotals["Total"]?.toFixed(2)}
            // disabled={true}
          />
          <Column
            field="Remarks"
            header="Remarks"
            editor={(options) => textEditor2(options)}
          />
          <Column
            rowEditor={allowEdit}
            header="Edit"
            style={{ width: "105px", textAlign: "center" }}
          />
          <Column
            header="Action"
            body={actionBodyTemplate}
            headerStyle={cellStyle}
            bodyStyle={cellStyle}
          />
        </DataTable>
      </div>

      <div className="flex justify-between items-center mt-3 mb-3">
        <div></div>
        {editableMode ? (
          <div className="flex gap-2">
            <CustomButton
              label="Update"
              icon="pi pi-save"
              className="p-button-sm"
              onClick={() => {
                const result = hasDuplicateDatesOrZeroTotal(tourClaimTableData);
                console.log("result", result);
                if (result.hasIssue) {
                  showWarningMessage(toastRef, "warn", result.reason);
                  // toast.current?.show({
                  //   severity: "warn",
                  //   summary: "Validation Warning",
                  //   detail: result.reason,
                  // });
                  return;
                }
                handleUpdate();
                //showSuccessMessage(toastRef, "success", "Tour claim updated!");
              }}
            />
            <CustomButton
              label="Home"
              icon="pi pi-home"
              onClick={() => {
                seteditableMode(false);
              }}
              className="p-button-sm"
              s
            />
          </div>
        ) : (
          <div className="flex gap-3">
            <CustomButton
              label="Save to Draft"
              icon="pi pi-save"
              className="p-button-sm"
              severity={"success"}
              style={{ padding: "0.5rem 0.7rem" }}
              onClick={() => {
                const result = hasDuplicateDatesOrZeroTotal(tourClaimTableData);
                if (result.hasIssue) {
                  showWarningMessage(toastRef, "warn", result.reason);
                  // toast.current?.show({
                  //   severity: "warn",
                  //   summary: "Validation Warning",
                  //   detail: result.reason,
                  // });
                  return;
                }
                handleSaveToDraft();
              }}
            />

            <CustomButton
              label="Home"
              icon="pi pi-home"
              onClick={() => {
                seteditableMode(false);
                settoggleNewClaim(false);
                settourClaimTableData([]);
                setselectedtravelMode(null);
              }}
              className="p-button-sm selectButtonStyle"
              size={"small"}
              style={{ padding: "0.5rem 0.7rem" }}
              disabled={draftData?.length === 0}

              // disabled={toggleNewClaim===true}
            />
          </div>
        )}
        <CustomButton
          // label="Add Row"
          icon="pi pi-plus"
          className="p-button-sm mr-4"
          severity="success"
          onClick={handleAddRow}
          tooltip="Add Row"
          rounded={"true"}
          size="small"
          style={{ width: "1rem", height: "2.1rem" }}
        />
      </div>
    </>
  );
};

export default TourClaimTable;